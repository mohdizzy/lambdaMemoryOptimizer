// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

const dispatchMinBatchSize = parseInt(process.env.DISPATCH_MIN_BATCH_SIZE || 1);
const {KinesisClient, PutRecordCommand} = require("@aws-sdk/client-kinesis");
const kinesisClient = new KinesisClient({region: process.env.REGION});

async function dispatch(queue, force) {
    try {
        if (queue.length !== 0 && (force || queue.length >= dispatchMinBatchSize)) {
            console.log('[telementry-dispatcher:dispatch] Dispatching', queue.length, 'telemetry events');;
            const requestBody = JSON.stringify({functionName: process.env.AWS_LAMBDA_FUNCTION_NAME,records:queue});
            queue.splice(0); 

            const params = {
                Data: Buffer.from(requestBody),
                StreamARN: process.env.STREAM_ARN,
                PartitionKey: process.env.AWS_LAMBDA_FUNCTION_NAME,
            };
            const kinesisPutRecordCommand = new PutRecordCommand(params);
            const data = await kinesisClient.send(kinesisPutRecordCommand);
            console.log("Kinesis put record response");
            console.log(data);
        }        
    } catch (error) {
        console.log(error)
        console.log('[telementry-dispatcher:dispatch] Error occurred. Discarding log events from the queue');
    }
}

module.exports = {
    dispatch
}
